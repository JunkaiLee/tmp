#!/bin/bash
#scrape container cpu usage

CONTAINER_ID=$1

if [ -z "$CONTAINER_ID" ]
then
    echo 0
    exit -1
fi

CTN_CGROUP_CPU_USAGE=$(cat /sys/fs/cgroup/cpuacct/docker/$CONTAINER_ID/cpuacct.usage)

if [ -z "$CTN_CGROUP_CPU_USAGE" ]
then
    echo 0
    exit -1
else
    echo $CTN_CGROUP_CPU_USAGE
fi
