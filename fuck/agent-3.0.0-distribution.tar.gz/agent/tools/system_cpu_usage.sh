#!/bin/bash
#scrape system total cpu usage from /proc/stat

FOR_DEBUG_FLAG=false
CPU_PERIOD_ARRAY=$(cat /proc/stat | grep 'cpu ' | awk '{print $2" "$3" "$4" "$5" "$6" "$7" "$8" "$9" "$10}')

if [ $FOR_DEBUG_FLAG = true ]
then
    echo cpu period array: $CPU_PERIOD_ARRAY
fi

if [ -z "$CPU_PERIOD_ARRAY" ]
then
    echo 0
    exit -1
else
    CPU_PERIOD_TOTAL=$(echo $CPU_PERIOD_ARRAY | awk '{print $1+$2+$3+$4+$5+$6+$7+$8+$9}')
    echo $CPU_PERIOD_TOTAL
fi
