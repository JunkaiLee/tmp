#!/bin/bash
#scrape container mem usage

CONTAINER_ID=$1

if [ -z "$CONTAINER_ID" ]
then
    echo 0
    exit -1
fi

MEMUSAGE_BYTE=$(cat /sys/fs/cgroup/memory/docker/$CONTAINER_ID/memory.usage_in_bytes)
MEM_INACTIVE_BYTE=$(cat /sys/fs/cgroup/memory/docker/$CONTAINER_ID/memory.stat | grep "total_inactive_file " | awk '{print $2}')
if [ -z "$MEMUSAGE_BYTE" ] || [ -z "$MEM_INACTIVE_BYTE" ]
then
    echo 0
    exit -1
else
   # MEMUSAGE=$(($MEMUSAGE_BYTE / 1024 / 1024|bc -l))
    MEMUSAGE=$(($MEMUSAGE_BYTE - $MEM_INACTIVE_BYTE))
    echo $MEMUSAGE
fi

